/**
 * Automatic verification-token forwarding has intentionally been disabled in this
 * safe patch. Do not add OTPs, SIM verification codes, credentials, or other
 * authentication secrets to Telegram notifications.
 *
 * Use this backend only for non-sensitive bot administration after adding
 * authenticated, least-privilege endpoints and appropriate tests.
 */
