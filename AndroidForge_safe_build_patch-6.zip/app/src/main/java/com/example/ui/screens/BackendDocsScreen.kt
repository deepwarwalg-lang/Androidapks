package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.IntegrationInstructions
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.StatusSuccess

@Composable
fun BackendDocsScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val cloudFunctionCode = """
const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const fetch = require("node-fetch");

admin.initializeApp();
const db = admin.firestore();

const telegramBotToken = defineSecret("TELEGRAM_BOT_TOKEN");
const telegramChatId = defineSecret("TELEGRAM_CHAT_ID");

exports.onVerificationTokenCreated = onDocumentCreated(
  {
    document: "verification_tokens/{tokenId}",
    secrets: [telegramBotToken, telegramChatId],
    region: "us-central1",
    timeoutSeconds: 15
  },
  async (event) => {
    const snap = event.data;
    if (!snap) return;

    const tokenId = event.params.tokenId;
    const docRef = snap.ref;
    const data = snap.data();

    // 1. Deduplication guard
    if (data.processed || data.telegramSent) return;

    // 2. Schema and authorization check
    if (!data.tokenRef || data.status !== "AUTHORIZED") return;

    // 3. Obtain secrets safely
    const botToken = telegramBotToken.value();
    const chatId = telegramChatId.value();

    // 4. Construct sanitized message (NO OTPs/passwords)
    const text = `<b>🔐 Authorized Verification Token</b>\n\n` +
      `📱 <b>App:</b> ${'$'}{data.appName || "Auto Token Sender"}\n` +
      `🏷️ <b>Ref:</b> <code>${'$'}{data.tokenRef}</code>\n` +
      `⏱️ <b>Created:</b> ${'$'}{new Date().toISOString()}\n` +
      `✅ <b>Status:</b> <b>AUTHORIZED</b>`;

    // 5. Dispatch within 2 seconds
    const url = `https://api.telegram.org/bot${'$'}{botToken}/sendMessage`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML" })
    });
    const result = await res.json();

    if (res.ok && result.ok) {
      await docRef.update({
        processed: true,
        telegramSent: true,
        sentAt: admin.firestore.FieldValue.serverTimestamp(),
        telegramMessageId: result.result.message_id
      });
    }
  }
);
""".trimIndent()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("backend_docs_screen")
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Column {
                Text(
                    text = "Backend & Setup Guide",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Deployment instructions for Firebase Cloud Functions & Telegram API",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Architecture Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.IntegrationInstructions,
                            contentDescription = null,
                            tint = CyanPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "End-to-End Automated Pipeline",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "1. Verification Token Generated ➔ Added to Firestore `/verification_tokens`\n" +
                               "2. Real-time Trigger ➔ Cloud Function (or Android Active Listener) activates in <200ms\n" +
                               "3. Schema Validation ➔ Ensures authorized status & token reference ID\n" +
                               "4. Sanitization ➔ Excludes passwords, OTPs, or authentication secrets\n" +
                               "5. Telegram Bot API ➔ Sent to chat within <2s delivery standard\n" +
                               "6. Deduplication Lock ➔ Flags document as processed with message ID",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        // CLI Commands Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Deployment CLI Commands", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }

                        IconButton(
                            onClick = {
                                val commands = """
# 1. Select Firebase Project
firebase use auto-verification-bf6cd

# 2. Configure Telegram Secrets
firebase functions:secrets:set TELEGRAM_BOT_TOKEN
firebase functions:secrets:set TELEGRAM_CHAT_ID

# 3. Deploy Cloud Functions
firebase deploy --only functions

# 4. Deploy Firestore Rules
firebase deploy --only firestore:rules
                                """.trimIndent()
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("CLI Commands", commands))
                                Toast.makeText(context, "Commands copied!", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyanPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "$ firebase use auto-verification-bf6cd\n" +
                                   "$ firebase functions:secrets:set TELEGRAM_BOT_TOKEN\n" +
                                   "$ firebase functions:secrets:set TELEGRAM_CHAT_ID\n" +
                                   "$ firebase deploy --only functions",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            color = CyanPrimary
                        )
                    }
                }
            }
        }

        // Source Code Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Code, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Cloud Function Source (index.js)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }

                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Cloud Function Code", cloudFunctionCode))
                                Toast.makeText(context, "Function code copied!", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy Code", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = cloudFunctionCode,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // APK Build Instructions
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("APK Build Instructions", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Build production APK with signed configuration:\n" +
                               "• Debug APK: gradle :app:assembleDebug\n" +
                               "• Release APK: gradle :app:assembleRelease\n" +
                               "Output files are located at:\n" +
                               "app/build/outputs/apk/release/app-release.apk",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
