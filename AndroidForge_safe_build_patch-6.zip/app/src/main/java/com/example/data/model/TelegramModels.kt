package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class TelegramSendMessageRequest(
    @Json(name = "chat_id")
    val chatId: String,
    @Json(name = "text")
    val text: String,
    @Json(name = "parse_mode")
    val parseMode: String = "HTML",
    @Json(name = "disable_web_page_preview")
    val disableWebPagePreview: Boolean = true
)

@JsonClass(generateAdapter = true)
data class TelegramBaseResponse<T>(
    @Json(name = "ok")
    val ok: Boolean,
    @Json(name = "result")
    val result: T? = null,
    @Json(name = "description")
    val description: String? = null,
    @Json(name = "error_code")
    val errorCode: Int? = null
)

@JsonClass(generateAdapter = true)
data class TelegramUser(
    @Json(name = "id")
    val id: Long,
    @Json(name = "is_bot")
    val isBot: Boolean,
    @Json(name = "first_name")
    val firstName: String,
    @Json(name = "username")
    val username: String? = null
)

@JsonClass(generateAdapter = true)
data class TelegramMessageResult(
    @Json(name = "message_id")
    val messageId: Long,
    @Json(name = "date")
    val date: Long
)

@JsonClass(generateAdapter = true)
data class TelegramChatResult(
    @Json(name = "id")
    val id: Long,
    @Json(name = "type")
    val type: String,
    @Json(name = "title")
    val title: String? = null,
    @Json(name = "username")
    val username: String? = null
)
