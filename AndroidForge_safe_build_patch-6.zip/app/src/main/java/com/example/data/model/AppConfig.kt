package com.example.data.model

data class AppConfig(
    val telegramBotToken: String = "",
    val telegramChatId: String = "",
    val isMonitoringActive: Boolean = false,
    val autoForwardDirectly: Boolean = false, // Whether Android forwards directly or relies on Cloud Function
    val filterAppId: String = "",
    val soundAlerts: Boolean = true,
    val targetDeliverySeconds: Int = 2
)
