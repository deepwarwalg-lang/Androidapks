package com.example.data.repository

import com.example.data.model.LogLevel
import com.example.data.model.VerificationToken
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.Date
import java.util.UUID

class FirestoreTokenRepository(
    private val firestore: FirebaseFirestore,
    private val logger: AppLogRepository
) {
    private val tokensCollection = firestore.collection("verification_tokens")

    /**
     * Observes real-time tokens ordered by creation date descending
     */
    fun observeTokens(): Flow<List<VerificationToken>> = callbackFlow {
        var registration: ListenerRegistration? = null
        try {
            registration = tokensCollection
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(100)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        logger.log(
                            LogLevel.ERROR,
                            "Firestore",
                            "Snapshot listener error",
                            error.localizedMessage
                        )
                        return@addSnapshotListener
                    }

                    if (snapshot != null) {
                        val tokenList = snapshot.documents.mapNotNull { doc ->
                            try {
                                val token = doc.toObject(VerificationToken::class.java)
                                token?.copy(id = doc.id)
                            } catch (e: Exception) {
                                logger.log(
                                    LogLevel.WARN,
                                    "Firestore",
                                    "Failed to parse document ${doc.id}",
                                    e.localizedMessage
                                )
                                null
                            }
                        }
                        trySend(tokenList)
                    }
                }
        } catch (e: Exception) {
            logger.log(LogLevel.ERROR, "Firestore", "Failed to attach listener", e.localizedMessage)
        }

        awaitClose {
            registration?.remove()
        }
    }

    /**
     * Creates a new authorized verification token document.
     * Useful for automated token creation and simulator testing.
     */
    suspend fun createToken(
        appName: String = "Auto Token Sender",
        status: String = "AUTHORIZED",
        customRef: String? = null
    ): Result<String> {
        return try {
            val randomSuffix = UUID.randomUUID().toString().take(6).uppercase()
            val tokenRef = customRef?.ifBlank { null } ?: "TKN-$randomSuffix"

            val tokenData = hashMapOf(
                "appId" to "com.rtajj",
                "appName" to appName,
                "tokenRef" to tokenRef,
                "status" to status.uppercase(),
                "isAuthorized" to (status.uppercase() == "AUTHORIZED" || status.uppercase() == "APPROVED"),
                "createdAt" to FieldValue.serverTimestamp(),
                "processed" to false,
                "telegramSent" to false
            )

            val docRef = tokensCollection.add(tokenData).await()
            logger.log(
                LogLevel.INFO,
                "Firestore",
                "Created new verification token record",
                "Doc ID: ${docRef.id} | Ref: $tokenRef | Status: $status"
            )
            Result.success(docRef.id)
        } catch (e: Exception) {
            logger.log(LogLevel.ERROR, "Firestore", "Failed to create token document", e.localizedMessage)
            Result.failure(e)
        }
    }

    /**
     * Atomically marks a token record as processed with delivery metadata
     */
    suspend fun markTokenProcessed(
        tokenId: String,
        telegramMessageId: Long?,
        latencyMs: Long?,
        error: String? = null
    ): Result<Unit> {
        return try {
            val updates = hashMapOf<String, Any>(
                "processed" to true,
                "telegramSent" to (error == null && telegramMessageId != null),
                "sentAt" to FieldValue.serverTimestamp(),
                "processedAt" to FieldValue.serverTimestamp()
            )

            if (telegramMessageId != null) {
                updates["telegramMessageId"] = telegramMessageId
            }
            if (latencyMs != null) {
                updates["deliveryLatencyMs"] = latencyMs
            }
            if (error != null) {
                updates["lastError"] = error
            }

            tokensCollection.document(tokenId).update(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            logger.log(LogLevel.WARN, "Firestore", "Failed to update processed status for $tokenId", e.localizedMessage)
            Result.failure(e)
        }
    }

    /**
     * Checks Firebase connection latency and project metadata
     */
    suspend fun checkConnection(): Pair<Boolean, Long> {
        val startTime = System.currentTimeMillis()
        return try {
            tokensCollection.limit(1).get().await()
            val latency = System.currentTimeMillis() - startTime
            true to latency
        } catch (e: Exception) {
            false to -1L
        }
    }

    fun getProjectId(): String {
        return try {
            FirebaseApp.getInstance().options.projectId ?: "auto-verification-bf6cd"
        } catch (e: Exception) {
            "auto-verification-bf6cd"
        }
    }
}
