package com.example.data.repository

import com.example.data.api.TelegramApiService
import com.example.data.model.LogLevel
import com.example.data.model.TelegramChatResult
import com.example.data.model.TelegramSendMessageRequest
import com.example.data.model.TelegramUser
import com.example.data.model.VerificationToken
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class TelegramRepository(
    private val api: TelegramApiService,
    private val logger: AppLogRepository
) {
    /**
     * Tests and verifies the Telegram Bot Token using getMe
     */
    suspend fun testBotToken(token: String): Result<TelegramUser> {
        val cleanToken = token.trim()
        if (cleanToken.isBlank()) {
            return Result.failure(IllegalArgumentException("Bot Token is empty"))
        }

        return try {
            val startTime = System.currentTimeMillis()
            val response = api.getMe(cleanToken)
            val duration = System.currentTimeMillis() - startTime

            if (response.isSuccessful && response.body()?.ok == true) {
                val user = response.body()?.result
                if (user != null) {
                    logger.log(
                        LogLevel.SUCCESS,
                        "TelegramBot",
                        "Bot token verified successfully in ${duration}ms",
                        "Bot: @${user.username ?: user.firstName} (ID: ${user.id})"
                    )
                    Result.success(user)
                } else {
                    Result.failure(Exception("Telegram returned empty user result"))
                }
            } else {
                val errorMsg = response.body()?.description ?: "HTTP ${response.code()} ${response.message()}"
                logger.log(LogLevel.ERROR, "TelegramBot", "Bot token validation failed", errorMsg)
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            logger.log(LogLevel.ERROR, "TelegramBot", "Network error verifying bot token", e.localizedMessage)
            Result.failure(e)
        }
    }

    /**
     * Checks if the target Chat ID is accessible by the bot
     */
    suspend fun testChatAccess(token: String, chatId: String): Result<TelegramChatResult> {
        val cleanToken = token.trim()
        val cleanChatId = chatId.trim()
        if (cleanToken.isBlank() || cleanChatId.isBlank()) {
            return Result.failure(IllegalArgumentException("Bot token and Chat ID are required"))
        }

        return try {
            val response = api.getChat(cleanToken, cleanChatId)
            if (response.isSuccessful && response.body()?.ok == true) {
                val chat = response.body()?.result
                if (chat != null) {
                    logger.log(
                        LogLevel.SUCCESS,
                        "TelegramChat",
                        "Chat access confirmed: ${chat.title ?: chat.username ?: chat.id}"
                    )
                    Result.success(chat)
                } else {
                    Result.failure(Exception("Chat result empty"))
                }
            } else {
                val error = response.body()?.description ?: "HTTP ${response.code()}"
                logger.log(LogLevel.WARN, "TelegramChat", "Failed to access Chat ID", error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Sends a sanitized verification token notification.
     * CRITICAL SECURITY: Only includes App Name, Token Reference ID, Creation Timestamp, Verification Status.
     * Passwords, OTPs, or authentication credentials are strictly excluded.
     *
     * @return Result containing Pair(messageId, latencyMs)
     */
    suspend fun sendVerificationTokenNotification(
        token: String,
        chatId: String,
        record: VerificationToken,
        maxRetries: Int = 2
    ): Result<Pair<Long, Long>> {
        val cleanToken = token.trim()
        val cleanChatId = chatId.trim()

        if (cleanToken.isBlank() || cleanChatId.isBlank()) {
            val err = "Telegram credentials not configured. Please set Bot Token and Chat ID."
            logger.log(LogLevel.ERROR, "Dispatcher", err)
            return Result.failure(IllegalStateException(err))
        }

        val sanitizedHtml = buildSanitizedNotificationHtml(record)
        val request = TelegramSendMessageRequest(
            chatId = cleanChatId,
            text = sanitizedHtml,
            parseMode = "HTML"
        )

        var lastException: Exception? = null
        for (attempt in 0..maxRetries) {
            val startTime = System.currentTimeMillis()
            try {
                val response = api.sendMessage(cleanToken, request)
                val latency = System.currentTimeMillis() - startTime

                if (response.isSuccessful && response.body()?.ok == true) {
                    val messageId = response.body()?.result?.messageId ?: 0L
                    logger.log(
                        LogLevel.SUCCESS,
                        "Dispatcher",
                        "Notification dispatched to Telegram in ${latency}ms (Target: <2000ms)",
                        "Token Ref: ${record.tokenRef.ifBlank { record.id }} | Msg ID: $messageId"
                    )
                    return Result.success(Pair(messageId, latency))
                } else {
                    val errorDesc = response.body()?.description ?: "HTTP ${response.code()} ${response.message()}"
                    lastException = Exception("Telegram API error: $errorDesc")

                    // Rate limit or server error - retry with backoff
                    if (response.code() == 429 || response.code() >= 500) {
                        logger.log(LogLevel.WARN, "Dispatcher", "Transient error, retrying ($attempt/$maxRetries)", errorDesc)
                        delay(500L * (attempt + 1))
                        continue
                    } else {
                        // Non-retryable error (e.g. invalid chat ID, bad token)
                        logger.log(LogLevel.ERROR, "Dispatcher", "Permanent dispatch failure", errorDesc)
                        break
                    }
                }
            } catch (e: Exception) {
                lastException = e
                logger.log(LogLevel.WARN, "Dispatcher", "Network exception on attempt $attempt", e.localizedMessage)
                if (attempt < maxRetries) {
                    delay(400L * (attempt + 1))
                }
            }
        }

        return Result.failure(lastException ?: Exception("Unknown error sending notification"))
    }

    /**
     * Builds sanitized notification HTML payload compliant with security requirements.
     */
    fun buildSanitizedNotificationHtml(token: VerificationToken): String {
        val appName = escapeHtml(token.appName.ifBlank { "Auto Token Sender" })
        val tokenRef = escapeHtml(token.tokenRef.ifBlank { token.id })
        val status = escapeHtml(token.status.uppercase())

        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        val timestampStr = token.createdAt?.let { sdf.format(it) } ?: sdf.format(Date())

        return """
            <b>🔐 Authorized Verification Token</b>

            📱 <b>Application:</b> $appName
            🏷️ <b>Token Reference:</b> <code>$tokenRef</code>
            ⏱️ <b>Created At:</b> $timestampStr
            ✅ <b>Status:</b> <b>$status</b>

            <i>⚡ Auto-forwarded within 2s delivery standard</i>
        """.trimIndent()
    }

    private fun escapeHtml(text: String): String {
        return text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
    }
}
