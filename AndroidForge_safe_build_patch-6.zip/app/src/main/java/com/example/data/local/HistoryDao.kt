package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.HistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {
    @Query("SELECT * FROM notification_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM notification_history WHERE tokenId = :tokenId LIMIT 1")
    suspend fun getByTokenId(tokenId: String): HistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(history: HistoryEntity)

    @Query("DELETE FROM notification_history")
    suspend fun clearHistory()

    @Query("SELECT COUNT(*) FROM notification_history WHERE isSuccess = 1")
    fun getSuccessCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM notification_history WHERE isSuccess = 0")
    fun getFailureCount(): Flow<Int>
}
