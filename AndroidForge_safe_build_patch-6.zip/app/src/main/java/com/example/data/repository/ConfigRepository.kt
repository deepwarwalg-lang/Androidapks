package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AppConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ConfigRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    private val _configFlow = MutableStateFlow(loadConfig())
    val configFlow: StateFlow<AppConfig> = _configFlow.asStateFlow()

    private fun loadConfig(): AppConfig {
        return AppConfig(
            telegramBotToken = prefs.getString(KEY_BOT_TOKEN, "") ?: "",
            telegramChatId = prefs.getString(KEY_CHAT_ID, "") ?: "",
            isMonitoringActive = prefs.getBoolean(KEY_MONITORING_ACTIVE, true),
            autoForwardDirectly = prefs.getBoolean(KEY_AUTO_FORWARD, false),
            filterAppId = prefs.getString(KEY_FILTER_APP_ID, "") ?: "",
            soundAlerts = prefs.getBoolean(KEY_SOUND_ALERTS, true),
            targetDeliverySeconds = prefs.getInt(KEY_TARGET_DELIVERY, 2)
        )
    }

    fun updateConfig(
        botToken: String,
        chatId: String,
        autoForward: Boolean = _configFlow.value.autoForwardDirectly,
        filterAppId: String = _configFlow.value.filterAppId,
        soundAlerts: Boolean = _configFlow.value.soundAlerts
    ) {
        prefs.edit()
            .putString(KEY_BOT_TOKEN, botToken.trim())
            .putString(KEY_CHAT_ID, chatId.trim())
            .putBoolean(KEY_AUTO_FORWARD, autoForward)
            .putString(KEY_FILTER_APP_ID, filterAppId.trim())
            .putBoolean(KEY_SOUND_ALERTS, soundAlerts)
            .apply()

        _configFlow.value = loadConfig()
    }

    fun setMonitoringActive(active: Boolean) {
        prefs.edit().putBoolean(KEY_MONITORING_ACTIVE, active).apply()
        _configFlow.value = _configFlow.value.copy(isMonitoringActive = active)
    }

    companion object {
        private const val PREFS_NAME = "auto_token_sender_prefs"
        private const val KEY_BOT_TOKEN = "key_bot_token"
        private const val KEY_CHAT_ID = "key_chat_id"
        private const val KEY_MONITORING_ACTIVE = "key_monitoring_active"
        private const val KEY_AUTO_FORWARD = "key_auto_forward"
        private const val KEY_FILTER_APP_ID = "key_filter_app_id"
        private const val KEY_SOUND_ALERTS = "key_sound_alerts"
        private const val KEY_TARGET_DELIVERY = "key_target_delivery"
    }
}
