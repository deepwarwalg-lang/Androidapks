package com.example

import com.example.data.api.TelegramApiService
import com.example.data.model.LogLevel
import com.example.data.model.VerificationToken
import com.example.data.repository.AppLogRepository
import com.example.data.repository.TelegramRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Date

class ExampleUnitTest {

    @Test
    fun verificationToken_validation_authorizedRecord() {
        val token = VerificationToken(
            id = "test-doc-123",
            tokenRef = "TKN-782910",
            status = "AUTHORIZED",
            isAuthorized = true,
            createdAt = Date()
        )
        val (isValid, reason) = token.isValidForNotification()
        assertTrue(isValid)
        assertEquals("Valid", reason)
    }

    @Test
    fun verificationToken_validation_unauthorizedStatus() {
        val token = VerificationToken(
            id = "test-doc-124",
            tokenRef = "TKN-782911",
            status = "REVOKED",
            isAuthorized = false,
            createdAt = Date()
        )
        val (isValid, reason) = token.isValidForNotification()
        assertFalse(isValid)
        assertTrue(reason.contains("not authorized"))
    }

    @Test
    fun verificationToken_validation_missingTokenRef() {
        val token = VerificationToken(
            id = "",
            tokenRef = "",
            status = "AUTHORIZED",
            isAuthorized = true
        )
        val (isValid, reason) = token.isValidForNotification()
        assertFalse(isValid)
        assertTrue(reason.contains("Missing token reference ID"))
    }

    @Test
    fun telegramNotification_zeroSecretsGuarantee() {
        val token = VerificationToken(
            id = "doc-999",
            appName = "Auto Token Sender",
            tokenRef = "TKN-948201",
            status = "AUTHORIZED",
            createdAt = Date()
        )

        val apiMock = TelegramApiService.create()
        val dummyLogger = object : AppLogRepository(object : com.example.data.local.LogDao {
            override fun getRecentLogs() = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.model.LogEntity>())
            override suspend fun insertLog(log: com.example.data.model.LogEntity) {}
            override suspend fun clearLogs() {}
            override fun getErrorCount() = kotlinx.coroutines.flow.flowOf(0)
        }) {}

        val repo = TelegramRepository(apiMock, dummyLogger)
        val html = repo.buildSanitizedNotificationHtml(token)

        // Verify strictly formatted fields are present
        assertTrue(html.contains("Application:</b> Auto Token Sender"))
        assertTrue(html.contains("Token Reference:</b> <code>TKN-948201</code>"))
        assertTrue(html.contains("Status:</b> <b>AUTHORIZED</b>"))

        // Verify sensitive terms are NOT contained
        assertFalse(html.contains("password", ignoreCase = true))
        assertFalse(html.contains("otp", ignoreCase = true))
        assertFalse(html.contains("secret", ignoreCase = true))
    }
}
